# Installation Guide - EPMA Security Tools 1.0

## Quick Installation

```bash
# Extract the package
tar -xzf epma-security-tools-1.0.tar.gz
cd epma-security-tools-1.0

# Install to /usr/local/bin
sudo cp bin/*.sh /usr/local/bin/

# Make sure scripts are executable
sudo chmod +x /usr/local/bin/security_checklist.sh
sudo chmod +x /usr/local/bin/service_optimizer.sh
```

## System Requirements

- **OS:** Ubuntu 20.04 LTS, 22.04 LTS, or 24.04 LTS
- **Shell:** Bash 4.0+
- **Permissions:** sudo access (for some checks)
- **Optional:** rkhunter (for malware detection)

## Usage

### Security Checklist
```bash
sudo security_checklist.sh
```

### Service Optimizer
```bash
sudo service_optimizer.sh
```

## Documentation

See `docs/README.md` for complete documentation and features.

## Support

For issues and feature requests, visit:
https://github.com/1985epma/checklist_linux

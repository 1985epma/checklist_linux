# Changelog - EPMA Security Tools

All notable changes to this project will be documented in this file.

## [1.0] - 2025-12-22

### Added
- Security Checklist script with comprehensive security verification
  - System updates checking
  - Firewall (UFW) status and rules
  - Running services analysis
  - User accounts verification
  - File permissions checks
  - SSH configuration analysis
  - Malware detection (rkhunter integration)
  - HTML and CSV report generation

- Service Optimizer script
  - Desktop mode optimization
  - Server mode optimization
  - Container mode optimization
  - Service configuration recommendations
  - Performance tuning

### Features
- Multi-format reports (HTML, CSV)
- Non-destructive checks (no automatic modifications except in auto mode)
- Support for Ubuntu 20.04, 22.04, 24.04 LTS
- CI/CD pipeline integration
- Comprehensive documentation

### License
MIT License - See LICENSE file for details

### Author
Everton Araujo
